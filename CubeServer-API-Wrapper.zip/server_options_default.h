/*
 * server_options.h
 * Copyright Joseph R. Freeston (MIT License)
 * 
 * Additional options for the library
 * 
 */

