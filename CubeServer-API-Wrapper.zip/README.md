# CubeServer-api-arduino
[![Maintainability](https://api.codeclimate.com/v1/badges/3637b71abcbcb0d8c30b/maintainability)](https://codeclimate.com/github/snorklerjoe/CubeServer-api-arduino/maintainability)

An arduino-C implementation of the API wrapper for this project

This currently only supports ESP8266, and only sort of...
(In development!)
